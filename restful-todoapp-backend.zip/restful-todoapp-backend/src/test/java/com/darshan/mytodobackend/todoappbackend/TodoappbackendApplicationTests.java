package com.darshan.mytodobackend.todoappbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoappbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
